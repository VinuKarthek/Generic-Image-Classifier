'''
Created on Sep 22, 2018

@author: Vinu Karthek
'''

class pygubu_app(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        