'''
Created on Sep 20, 2018

@author: Vinu Karthek
'''

class datavis(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        