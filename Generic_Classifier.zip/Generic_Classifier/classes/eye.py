'''
Created on Oct 6, 2018

@author: Vinu Karthek
'''

class eye(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        